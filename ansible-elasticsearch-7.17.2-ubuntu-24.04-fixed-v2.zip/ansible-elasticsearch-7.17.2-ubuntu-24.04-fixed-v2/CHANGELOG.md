# Fixed v2 changes

## Parser hotfix

- Removed Bash array-length expressions from all Ansible shell task bodies.
- Replaced bootstrap global-state scanning with `ansible.builtin.command` plus
  `argv`, calling `/usr/bin/find` without shell parsing.
- Reworked startup log collection so it does not use Bash array counting.
- Converted remaining shell tasks to the full dictionary form with `cmd` and
  `executable`, reducing free-form argument parsing.
- Added `scripts/validate-bundle.sh` to parse YAML/Jinja, scan for the unsafe
  Bash pattern, and run `ansible-playbook --syntax-check` for every playbook.
- Pinned the controller to `ansible-core==2.19.11` through `requirements.txt`.

## Existing fixed-edition behavior retained

- Bootstrap detection uses an Ansible marker or committed `global-*.st` state,
  not the mere presence of a `nodes/` directory.
- `bootstrap.memory_lock` defaults to false while swap is disabled.
- Dedicated `ES_TMPDIR`, `java.io.tmpdir`, and `jna.tmpdir` are configured.
- The bundled Elasticsearch JDK is selected in the systemd override.
- X-Pack ML is disabled by default for this legacy Elasticsearch deployment.
- Startup failures automatically print systemd, journal, application-log,
  configuration, JVM, and effective limit diagnostics.
- Destructive reset and reset-and-install playbooks are included.
- Verification checks that all nodes share one cluster UUID and exact version.
