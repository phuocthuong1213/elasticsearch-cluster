#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ "$(id -u)" -eq 0 ]]; then
  SUDO=""
else
  SUDO="sudo"
fi

$SUDO apt-get update
$SUDO apt-get install -y python3 python3-venv python3-pip sshpass unzip

python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip wheel
.venv/bin/python -m pip install -r requirements.txt

echo
echo 'Controller ready.'
echo 'Run: source .venv/bin/activate'
echo 'Then: ansible-playbook --version'
echo 'Validate: ./scripts/validate-bundle.sh'
