#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ -x .venv/bin/python ]]; then
  PYTHON=.venv/bin/python
else
  PYTHON=python3
fi

if [[ -x .venv/bin/ansible-playbook ]]; then
  ANSIBLE_PLAYBOOK=.venv/bin/ansible-playbook
elif command -v ansible-playbook >/dev/null 2>&1; then
  ANSIBLE_PLAYBOOK="$(command -v ansible-playbook)"
else
  echo 'ERROR: ansible-playbook not found. Run ./scripts/install-controller.sh first.' >&2
  exit 1
fi

"$PYTHON" - <<'PY'
from pathlib import Path
import json
import yaml
from jinja2 import Environment, StrictUndefined

root = Path('.')

class UniqueKeyLoader(yaml.SafeLoader):
    pass


def construct_mapping(loader, node, deep=False):
    mapping = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in mapping:
            raise yaml.constructor.ConstructorError(
                'while constructing a mapping', node.start_mark,
                f'found duplicate key {key!r}', key_node.start_mark,
            )
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    construct_mapping,
)

env = Environment()
yaml_count = 0
jinja_count = 0


def walk(value, source):
    global jinja_count
    if isinstance(value, dict):
        for key, child in value.items():
            walk(key, source)
            walk(child, source)
    elif isinstance(value, list):
        for child in value:
            walk(child, source)
    elif isinstance(value, str) and any(token in value for token in ('{{', '{%', '{#')):
        env.parse(value)
        jinja_count += 1


for path in sorted(root.rglob('*')):
    if not path.is_file():
        continue

    text = path.read_text(encoding='utf-8')

    if path.suffix in {'.yml', '.yaml'}:
        if text.startswith('$ANSIBLE_VAULT;'):
            continue
        documents = list(yaml.load_all(text, Loader=UniqueKeyLoader))
        yaml_count += 1
        for document in documents:
            walk(document, path)

        # Bash array/string length syntax contains the same character pair used
        # to open a Jinja comment and caused the parser failure in fixed-v1.
        if '${#' in text:
            raise RuntimeError(f'unsafe Bash/Jinja collision in {path}')

    elif path.suffix == '.j2':
        env.parse(text)
        jinja_count += 1

# Render the security template in all important modes and parse the result as YAML.
render_env = Environment(undefined=StrictUndefined)
render_env.filters.update(
    to_json=json.dumps,
    bool=bool,
    lower=lambda value: str(value).lower(),
)
template = render_env.from_string(
    (root / 'roles/elasticsearch/templates/elasticsearch.yml.j2').read_text()
)
context = {
    'es_cluster_name': 'prod-elasticsearch',
    'inventory_hostname': 'es01',
    'es_node_roles': ['master', 'data', 'ingest'],
    'es_data_path': '/var/lib/elasticsearch',
    'es_log_path': '/var/log/elasticsearch',
    'es_node_ip': '172.24.31.144',
    'es_http_port': 9200,
    'es_transport_port': 9300,
    'es_master_nodes': ['es01', 'es02', 'es03'],
    'hostvars': {
        'es01': {'es_node_ip': '172.24.31.144'},
        'es02': {'es_node_ip': '172.24.31.145'},
        'es03': {'es_node_ip': '172.24.31.146'},
    },
    'es_include_initial_master_nodes': True,
    'es_bootstrap_memory_lock': False,
    'es_security_enabled': True,
    'es_transport_ssl_enabled': True,
    'es_transport_ssl_verification_mode': 'certificate',
    'es_transport_ssl_client_authentication': 'required',
    'es_transport_cert_config_path': 'certs/elastic-certificates.p12',
    'es_http_ssl_enabled': False,
    'es_xpack_ml_enabled': False,
    'es_ingest_geoip_downloader_enabled': False,
}

secure = yaml.safe_load(template.render(**context))
assert secure['xpack.security.enabled'] is True
assert secure['xpack.security.transport.ssl.enabled'] is True
assert secure['xpack.security.transport.ssl.keystore.path'] == 'certs/elastic-certificates.p12'
assert secure['xpack.security.transport.ssl.truststore.path'] == 'certs/elastic-certificates.p12'
assert secure['xpack.security.http.ssl.enabled'] is False
assert secure['cluster.initial_master_nodes'] == ['es01', 'es02', 'es03']

context['es_include_initial_master_nodes'] = False
post_bootstrap = yaml.safe_load(template.render(**context))
assert 'cluster.initial_master_nodes' not in post_bootstrap

context['es_security_enabled'] = False
unsecured = yaml.safe_load(template.render(**context))
assert unsecured['xpack.security.enabled'] is False
assert unsecured['xpack.security.transport.ssl.enabled'] is False

print(f'YAML parse and duplicate-key check: OK ({yaml_count} files)')
print(f'Jinja syntax check: OK ({jinja_count} values/templates)')
print('Rendered Elasticsearch security configurations: OK')
PY

for script in scripts/*.sh; do
  bash -n "$script"
done

echo 'Bash syntax checks: OK'

for playbook in \
  site.yml \
  reset-cluster.yml \
  reset-and-install.yml \
  verify.yml \
  diagnose.yml \
  rolling-restart.yml; do
  "$ANSIBLE_PLAYBOOK" \
    -i inventory/hosts.yml \
    --syntax-check \
    "$playbook" \
    "$@"
done

echo 'Ansible syntax checks: OK'
