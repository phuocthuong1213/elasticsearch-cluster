# Ansible Elasticsearch 7.17.2 — Ubuntu 24.04 — 3-node cluster

Bộ này triển khai Elasticsearch `7.17.2` trên Ubuntu `24.04` với:

- TCP `9200`: HTTP REST API.
- TCP `9300`: transport nội bộ giữa các Elasticsearch node; không phải HTTP.
- Ba node mặc định đều có role `master`, `data`, `ingest`.
- Package `.deb` chính thức, xác thực SHA-512, dùng bundled JDK.
- Tắt swap, đặt `vm.max_map_count=262144`, file descriptor và thread limits.
- `bootstrap.memory_lock=false` mặc định để tránh lỗi mlock trên VM/hypervisor.
- Dedicated `ES_TMPDIR` và `-Djna.tmpdir` để tránh lỗi khi `/tmp` dùng `noexec`.
- Tắt X-Pack ML native process mặc định để tăng tương thích với bản ES cũ.
- Tự nhận biết committed cluster state; không còn lỗi sai kiểu
  `data already exists, but no bootstrap marker was found` sau một lần start dở dang.
- Khi startup lỗi, playbook tự in `systemctl status`, journal, Elasticsearch log,
  JVM options và effective systemd limits ngay trong output Ansible.
- Sau khi cluster hình thành, tự xóa `cluster.initial_master_nodes` khỏi cấu hình.

> Cấu hình theo yêu cầu là HTTP plaintext, `xpack.security.enabled=false`.
> Chỉ triển khai trong private network và giới hạn firewall.

## 1. Giải nén

```bash
unzip ansible-elasticsearch-7.17.2-ubuntu-24.04-fixed.zip
cd ansible-elasticsearch-7.17.2-ubuntu-24.04-fixed
```

## 2. Cài Ansible trên controller

```bash
chmod +x scripts/install-controller.sh
./scripts/install-controller.sh
source .venv/bin/activate
```

## 3. Sửa inventory

```bash
nano inventory/hosts.yml
```

Đổi `ansible_host` và `es_node_ip` thành IP thật của ba máy. Ví dụ:

```yaml
es01:
  ansible_host: 172.24.31.144
  es_node_ip: 172.24.31.144
```

- `ansible_host`: IP SSH.
- `es_node_ip`: IP private mà Elasticsearch bind cho 9200/9300.
- `es01`, `es02`, `es03`: trở thành `node.name`.

SSH bằng user có sudo:

```yaml
ansible_user: ubuntu
ansible_become: true
```

SSH trực tiếp bằng root:

```yaml
ansible_user: root
ansible_become: false
```

Không ghi password vào YAML. Dùng `-k` để hỏi SSH password và `-K` để hỏi sudo password.

## 4. Sửa heap và storage

```bash
nano inventory/group_vars/elasticsearch.yml
```

Ví dụ máy 8 GB RAM:

```yaml
es_heap_mb: 4096
```

Dùng disk riêng mount tại `/data`:

```yaml
es_data_path: /data/elasticsearch
es_tmp_path: /data/elasticsearch/tmp
es_require_data_mount: true
es_data_mountpoint: /data
```

## 5. Kiểm tra SSH

```bash
ansible elasticsearch -m ping -k -K
```

Kiểm tra inventory:

```bash
ansible-inventory --graph
```

## 6. Lệnh dành cho cluster hiện tại đang cài lỗi

Cluster của bạn đang là cluster mới, đã có data tạm từ lần startup thất bại. Chạy lệnh dưới đây để dừng Elasticsearch, xóa data trên cả ba node rồi cài sạch lại:

```bash
ansible-playbook reset-and-install.yml \
  -k -K \
  -e es_confirm_reset=true \
  -vv
```

**Lệnh này xóa toàn bộ Elasticsearch data trên cả ba node.** Chỉ dùng khi cluster chưa có dữ liệu cần giữ.

Nếu đăng nhập trực tiếp bằng root:

```bash
ansible-playbook reset-and-install.yml \
  -u root -k \
  -e es_confirm_reset=true \
  -vv
```

## 7. Các lần chạy idempotent sau này

Không reset data nữa. Chạy:

```bash
ansible-playbook site.yml -k -K -vv
```

Không dùng `--limit es01` trong lần bootstrap đầu tiên. Cả ba master-eligible node phải được cấu hình đồng nhất.

## 8. Kiểm tra cluster

```bash
ansible-playbook verify.yml -k -K
```

Hoặc:

```bash
curl -s http://10.10.10.11:9200/ | jq
curl -s http://10.10.10.11:9200/_cluster/health?pretty
curl -s 'http://10.10.10.11:9200/_cat/nodes?v&h=name,ip,node.role,master,version,heap.percent,ram.percent,cpu'
```

Kết quả cần có:

```text
version.number = 7.17.2
cluster_name = prod-elasticsearch
number_of_nodes = 3
status = yellow hoặc green
```

## 9. Nếu còn lỗi

Bản fixed tự in log thật ngay tại task startup. Có thể chạy riêng:

```bash
ansible-playbook diagnose.yml -k -K
```

Các lỗi được xử lý sẵn:

| Lỗi | Cách bộ Ansible xử lý |
|---|---|
| `memory locking requested ... not locked` | `bootstrap.memory_lock=false`, swap off |
| `/tmp noexec`, JNA unavailable | dedicated `ES_TMPDIR`, `-Djna.tmpdir` |
| `data already exists, no marker` sau start dở dang | phát hiện `global-*.st`, không chặn theo thư mục `nodes/` |
| stale systemd failed state | `systemctl reset-failed` trước start |
| sai quyền data/log/tmp | tạo đúng owner `elasticsearch:elasticsearch` |
| sai IP bind | preflight xác nhận `es_node_ip` có trên interface |
| heap vượt RAM | preflight chặn trước startup |
| service fail nhưng Ansible chỉ báo chung chung | tự thu thập systemd/journal/application log |
| split cluster | verify cluster UUID trên cả ba node |

## 10. Rolling restart

Sau khi cluster đã chạy ổn định:

```bash
ansible-playbook rolling-restart.yml -k -K
```

## 11. Firewall tối thiểu

Chỉ mở 9300 giữa ba node. Chỉ mở 9200 cho subnet ứng dụng/monitoring. Không mở trực tiếp ra Internet.

Ví dụ:

```bash
sudo ufw allow from 10.10.10.11 to any port 9300 proto tcp
sudo ufw allow from 10.10.10.12 to any port 9300 proto tcp
sudo ufw allow from 10.10.10.13 to any port 9300 proto tcp
sudo ufw allow from 10.10.20.0/24 to any port 9200 proto tcp
```

## 12. Cài offline

Copy package `elasticsearch-7.17.2-amd64.deb` vào controller rồi sửa:

```yaml
es_package_source: local
es_local_package_path: /opt/packages/elasticsearch-7.17.2-amd64.deb
es_local_package_sha512: "SHA512_HERE"
```

Sau đó chạy bình thường:

```bash
ansible-playbook site.yml -k -K -vv
```

## Tài liệu chính thức liên quan

- Debian package và bundled JDK: Elastic self-managed Debian package documentation.
- Cluster bootstrap: `cluster.initial_master_nodes` chỉ dành cho cluster hoàn toàn mới và phải xóa sau khi cluster hình thành.
- Disable swapping / memory lock: Elastic system memory configuration documentation.
- JNA temp directory: Elastic executable JNA temporary directory documentation.
