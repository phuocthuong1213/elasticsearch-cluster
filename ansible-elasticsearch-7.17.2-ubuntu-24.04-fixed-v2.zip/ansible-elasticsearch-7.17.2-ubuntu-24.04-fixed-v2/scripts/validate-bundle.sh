#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ -x .venv/bin/python ]]; then
  PYTHON=.venv/bin/python
else
  PYTHON=python3
fi

if [[ -x .venv/bin/ansible-playbook ]]; then
  ANSIBLE_PLAYBOOK=.venv/bin/ansible-playbook
elif command -v ansible-playbook >/dev/null 2>&1; then
  ANSIBLE_PLAYBOOK="$(command -v ansible-playbook)"
else
  echo 'ERROR: ansible-playbook not found. Run ./scripts/install-controller.sh first.' >&2
  exit 1
fi

"$PYTHON" - <<'PY'
from pathlib import Path
import sys

try:
    import yaml
    from jinja2 import Environment
except Exception as exc:
    print(f"ERROR: missing Python validation dependency: {exc}", file=sys.stderr)
    raise SystemExit(1)

root = Path('.')
env = Environment()
yaml_count = 0
jinja_count = 0


def walk(value, source):
    global jinja_count
    if isinstance(value, dict):
        for key, child in value.items():
            walk(key, source)
            walk(child, source)
    elif isinstance(value, list):
        for child in value:
            walk(child, source)
    elif isinstance(value, str) and ('{{' in value or '{%' in value):
        env.parse(value)
        jinja_count += 1

for path in sorted(root.rglob('*')):
    if path.suffix in {'.yml', '.yaml'}:
        documents = list(yaml.safe_load_all(path.read_text(encoding='utf-8')))
        yaml_count += 1
        for document in documents:
            walk(document, path)
    elif path.suffix == '.j2':
        env.parse(path.read_text(encoding='utf-8'))
        jinja_count += 1

print(f'YAML parse OK: {yaml_count} files')
print(f'Jinja syntax OK: {jinja_count} values/templates')
PY

# Bash array-length syntax contains the same character pair used to open a
# Jinja comment and can break Ansible argument splitting.
if grep -RIn --include='*.yml' --include='*.yaml' '\${#' .; then
  echo 'ERROR: found unsafe Bash array/string length syntax in YAML.' >&2
  exit 1
fi

echo 'Unsafe Bash/Jinja collision scan: OK'

for playbook in \
  site.yml \
  reset-cluster.yml \
  reset-and-install.yml \
  verify.yml \
  diagnose.yml \
  rolling-restart.yml; do
  "$ANSIBLE_PLAYBOOK" -i inventory/hosts.yml --syntax-check "$playbook"
done

echo 'Ansible syntax checks: OK'
