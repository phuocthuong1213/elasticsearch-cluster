# Changelog

## secure-v3

- Bật `xpack.security.enabled` theo biến cấu hình.
- Bật mutual TLS cho transport TCP 9300, xử lý đúng bootstrap check của Basic license.
- Giữ HTTP TCP 9200 plaintext theo yêu cầu.
- Tự sinh CA và `elastic-certificates.p12` bằng `elasticsearch-certutil`.
- Tự phân phối PKCS#12 tới cả ba node.
- Lưu PKCS#12 password và bootstrap password trong Elasticsearch keystore.
- Tự đặt password cho built-in users bằng Change Password API, đặt `elastic` cuối cùng.
- Tự xóa transient `bootstrap.password` sau khi khởi tạo.
- Readiness chấp nhận HTTP 401 trước khi built-in passwords được đặt.
- Verify và rolling restart hỗ trợ Basic Auth.
- Reset cluster xóa cả marker password initialization.
- Giữ các bản sửa parser Bash/Jinja, JNA temp, swap, heap, bootstrap marker và diagnostics từ fixed-v2.
