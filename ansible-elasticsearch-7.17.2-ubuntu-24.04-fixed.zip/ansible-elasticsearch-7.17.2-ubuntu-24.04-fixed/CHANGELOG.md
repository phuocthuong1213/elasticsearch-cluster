# Fixed edition changes

- Removed the unsafe guard that treated any `path.data/nodes` directory as an
  already-bootstrapped cluster.
- Bootstrap detection now uses the Ansible marker or committed `global-*.st` state.
- `bootstrap.memory_lock` defaults to false while swap is disabled.
- Added dedicated `ES_TMPDIR`, `java.io.tmpdir`, and `jna.tmpdir`.
- Forced the bundled Elasticsearch JDK through the systemd service environment.
- Disabled X-Pack ML native process by default for legacy-version compatibility.
- Added `systemctl reset-failed` before service startup.
- Added immediate automatic diagnostics if service startup or port readiness fails.
- Added safe destructive reset and reset-and-install playbooks.
- Added cross-node cluster UUID verification to detect split clusters.
