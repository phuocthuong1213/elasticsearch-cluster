#!/usr/bin/env bash
set -euo pipefail

if [[ "$(id -u)" -eq 0 ]]; then
  SUDO=""
else
  SUDO="sudo"
fi

$SUDO apt-get update
$SUDO apt-get install -y python3 python3-venv python3-pip sshpass unzip

python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip wheel
.venv/bin/python -m pip install 'ansible-core>=2.17,<2.20'

echo
echo 'Controller ready.'
echo 'Run: source .venv/bin/activate'
echo 'Then: ansible-playbook --version'
