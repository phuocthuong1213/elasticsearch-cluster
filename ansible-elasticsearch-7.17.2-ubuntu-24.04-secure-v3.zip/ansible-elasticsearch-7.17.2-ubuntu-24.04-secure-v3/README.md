# Elasticsearch 7.17.2 cluster trên Ubuntu 24.04 — Ansible secure v3

Bộ Ansible này cài cluster Elasticsearch 7.17.2 gồm 3 node trên Ubuntu 24.04:

- HTTP REST API: TCP `9200`.
- Transport giữa các node: TCP `9300` với mutual TLS.
- `xpack.security.enabled: true`.
- Username quản trị: `elastic`.
- Password được lấy từ Ansible Vault, không hard-code vào role.
- HTTP 9200 vẫn là plaintext theo yêu cầu; username/password dùng Basic Auth.
- Tự tạo CA và PKCS#12 certificate bằng `elasticsearch-certutil`.
- Tự phân phối certificate tới mọi node.
- Tự đặt password cho các built-in users lần đầu bằng bootstrap password.
- Tự xử lý HTTP `401` trong giai đoạn security đã bật nhưng password chưa được khởi tạo.
- Bootstrap cluster an toàn và tự xóa `cluster.initial_master_nodes` sau khi cluster hình thành.
- Có reset, verify, diagnose và rolling restart.

> Elasticsearch 7.17.2 là phiên bản cũ và Ubuntu 24.04 ra đời sau phiên bản này. Hãy kiểm thử staging trước khi dùng production.

## 1. Sửa inventory

Khi chuyển từ bản `fixed-v2`, chỉ mang sang IP/user SSH trong `inventory/hosts.yml`.
Không ghi đè file `inventory/group_vars/elasticsearch.yml` mới bằng file cũ vì bản v3
có thêm toàn bộ biến transport TLS và authentication.

```bash
nano inventory/hosts.yml
```

Ví dụ:

```yaml
all:
  children:
    elasticsearch:
      hosts:
        es01:
          ansible_host: 172.24.31.144
          es_node_ip: 172.24.31.144
          es_node_roles: [master, data, ingest]

        es02:
          ansible_host: 172.24.31.145
          es_node_ip: 172.24.31.145
          es_node_roles: [master, data, ingest]

        es03:
          ansible_host: 172.24.31.146
          es_node_ip: 172.24.31.146
          es_node_roles: [master, data, ingest]

      vars:
        ansible_user: ubuntu
        ansible_become: true
        ansible_python_interpreter: /usr/bin/python3
```

## 2. Tạo Ansible Vault chứa password

```bash
cp inventory/group_vars/all/vault.yml.example \
   inventory/group_vars/all/vault.yml

nano inventory/group_vars/all/vault.yml
```

Đặt password mạnh:

```yaml
vault_es_security_bootstrap_password: "BOOTSTRAP_PASSWORD_RAT_MANH"
vault_es_elastic_password: "ELASTIC_PASSWORD_RAT_MANH"
vault_es_system_users_password: "SYSTEM_USERS_PASSWORD_RAT_MANH"
vault_es_transport_ca_password: "CA_P12_PASSWORD_RAT_MANH"
vault_es_transport_cert_password: "NODE_P12_PASSWORD_RAT_MANH"
```

Mã hóa file:

```bash
ansible-vault encrypt inventory/group_vars/all/vault.yml
```

Không commit file vault plaintext lên Git.

## 3. Kiểm tra SSH

SSH và sudo đều dùng password:

```bash
ansible elasticsearch \
  -i inventory/hosts.yml \
  -m ping \
  -k -K \
  --ask-vault-pass
```

Trong đó:

- `-k`: hỏi SSH password.
- `-K`: hỏi sudo password.
- `--ask-vault-pass`: hỏi password giải mã Ansible Vault.

## 4. Kiểm tra syntax

```bash
ansible-playbook \
  -i inventory/hosts.yml \
  site.yml \
  --syntax-check \
  --ask-vault-pass
```

## 5. Sửa lỗi hiện tại mà không xóa data

Lỗi:

```text
Transport SSL must be enabled if security is enabled on a [basic] license
```

xảy ra vì `xpack.security.enabled: true` nhưng TLS transport 9300 chưa được cấu hình. Bộ v3 tự tạo certificate, bật transport TLS và khởi tạo password.

Chạy:

```bash
ansible-playbook \
  -i inventory/hosts.yml \
  site.yml \
  -k -K \
  --ask-vault-pass \
  -vv
```

Không cần xóa `/var/lib/elasticsearch` chỉ để sửa lỗi transport TLS.

Bật TLS transport là thay đổi static và cần **full cluster restart**. Playbook sẽ
restart cả ba node, vì vậy hãy bố trí thời gian gián đoạn nếu cluster đang phục vụ production.

## 6. Cài lại cluster mới hoàn toàn

Chỉ dùng khi cluster chưa có dữ liệu cần giữ:

```bash
ansible-playbook \
  -i inventory/hosts.yml \
  reset-and-install.yml \
  -k -K \
  --ask-vault-pass \
  -e es_confirm_reset=true \
  -vv
```

Lệnh này xóa toàn bộ dữ liệu Elasticsearch trên cả ba node.

## 7. Username và password

Sau khi playbook hoàn tất:

```text
Username: elastic
Password: giá trị vault_es_elastic_password
```

Ví dụ kiểm tra:

```bash
curl -u elastic:'ELASTIC_PASSWORD_RAT_MANH' \
  http://172.24.31.144:9200/
```

Cluster health:

```bash
curl -u elastic:'ELASTIC_PASSWORD_RAT_MANH' \
  http://172.24.31.144:9200/_cluster/health?pretty
```

Danh sách node:

```bash
curl -u elastic:'ELASTIC_PASSWORD_RAT_MANH' \
  'http://172.24.31.144:9200/_cat/nodes?v'
```

Password không được playbook in ra màn hình.

## 8. Kiểm tra cluster bằng Ansible

```bash
ansible-playbook \
  -i inventory/hosts.yml \
  verify.yml \
  -k -K \
  --ask-vault-pass
```

## 9. Diagnose

```bash
ansible-playbook \
  -i inventory/hosts.yml \
  diagnose.yml \
  -k -K \
  --ask-vault-pass
```

## 10. Rolling restart

```bash
ansible-playbook \
  -i inventory/hosts.yml \
  rolling-restart.yml \
  -k -K \
  --ask-vault-pass
```

Playbook xử lý từng node một bằng `serial: 1`.

## 11. Cấu hình security được render

```yaml
xpack.security.enabled: true
xpack.security.transport.ssl.enabled: true
xpack.security.transport.ssl.verification_mode: certificate
xpack.security.transport.ssl.client_authentication: required
xpack.security.transport.ssl.keystore.path: certs/elastic-certificates.p12
xpack.security.transport.ssl.truststore.path: certs/elastic-certificates.p12
xpack.security.http.ssl.enabled: false
```

Certificate nằm tại:

```text
/etc/elasticsearch/certs/elastic-certificates.p12
```

CA private key chỉ nằm trên node đầu tiên:

```text
/etc/elasticsearch/certs/elastic-stack-ca.p12
```

Một bản transport certificate tạm được lưu trên Ansible controller trong:

```text
.artifacts/<cluster-name>/elastic-certificates.p12
```

Bảo vệ thư mục `.artifacts` và không commit vào Git.

## 12. Firewall

- Chỉ mở TCP 9300 giữa các Elasticsearch node.
- Chỉ mở TCP 9200 cho subnet ứng dụng, Kibana và monitoring.
- Không public 9200/9300 ra Internet.

HTTP 9200 đang không mã hóa. Basic Auth bảo vệ quyền truy cập nhưng password vẫn đi qua kết nối HTTP; chỉ dùng trong mạng private hoặc đặt reverse proxy HTTPS ở phía trước.

## 13. Chuyển về chế độ không username/password

Không khuyến nghị cho production. Đặt:

```yaml
es_security_enabled: false
```

Sau đó chạy lại `site.yml`. Khi security tắt, không cần transport TLS, nhưng mọi client có thể truy cập nếu firewall cho phép.
