# Ansible Elasticsearch 7.17.2 Cluster — Ubuntu 24.04

Bộ Ansible này triển khai **Elasticsearch 7.17.2** trên đúng **Ubuntu Server 24.04**, mặc định theo mô hình **3 node**:

- TCP `9200`: HTTP REST API cho ứng dụng, Kibana và quản trị.
- TCP `9300`: transport nội bộ giữa các node Elasticsearch; không phải HTTP.
- Mỗi node mặc định có role `master`, `data`, `ingest`.
- Cài đúng gói `.deb` `7.17.2` từ artifact chính thức của Elastic.
- Dùng JDK được đóng gói sẵn trong Elasticsearch, không cài Java hệ thống.
- Xác minh SHA-512 trước khi cài.
- Cấu hình heap, `vm.max_map_count`, file descriptor, memory lock và swap.
- Bootstrap cluster một lần, sau đó tự loại `cluster.initial_master_nodes` khỏi cấu hình.
- Giữ package ở trạng thái `hold` để Ubuntu không tự nâng phiên bản.

## Cảnh báo tương thích

Elasticsearch `7.17.2` được phát hành trước Ubuntu `24.04` và không phải tổ hợp được Elastic hỗ trợ chính thức. Bộ này giữ đúng phiên bản theo yêu cầu và dùng package/JDK chính thức, nhưng cần kiểm thử kỹ snapshot/restore, plugin, tải thực tế và quy trình khôi phục trước production.

Nếu ứng dụng chỉ yêu cầu API `7.17.x` thay vì bắt buộc đúng `7.17.2`, nên cân nhắc một bản vá `7.17.x` mới hơn hoặc lên nhánh đang còn hỗ trợ.

Cluster này chạy **HTTP không username/password và không TLS**:

```yaml
xpack.security.enabled: false
```

Không được public `9200` hoặc `9300` ra Internet.

## 1. Cấu trúc

```text
ansible-elasticsearch-7.17.2-ubuntu-24.04/
├── ansible.cfg
├── inventory/
│   ├── hosts.yml
│   └── group_vars/elasticsearch.yml
├── roles/elasticsearch/
│   ├── defaults/main.yml
│   ├── tasks/
│   └── templates/
├── scripts/install-ansible-controller.sh
├── site.yml
├── rolling-update.yml
└── verify.yml
```

## 2. Chuẩn bị máy Ansible controller

Trên Ubuntu 24.04:

```bash
cd ansible-elasticsearch-7.17.2-ubuntu-24.04
./scripts/install-ansible-controller.sh
source .venv/bin/activate
ansible-playbook --version
```

Có thể dùng controller Linux khác. Script hiện cài `ansible-core >= 2.20, < 2.22`, phù hợp Python 3.12 của Ubuntu 24.04. Target nodes phải là Ubuntu 24.04, có SSH và tài khoản sudo.

## 3. Sửa IP và SSH account

Mở:

```bash
nano inventory/hosts.yml
```

Thay các IP mẫu:

```yaml
es01:
  ansible_host: 10.10.10.11
  es_node_ip: 10.10.10.11
```

- `ansible_host`: IP dùng để SSH.
- `es_node_ip`: IP private mà Elasticsearch bind/publish cả `9200` và `9300`.
- `es01`, `es02`, `es03`: trở thành `node.name`.

Nếu SSH bằng root:

```yaml
vars:
  ansible_user: root
  ansible_become: false
```

Nếu dùng private key riêng:

```yaml
vars:
  ansible_ssh_private_key_file: /home/admin/.ssh/id_rsa
```

## 4. Sửa cấu hình cluster

Mở:

```bash
nano inventory/group_vars/elasticsearch.yml
```

Các biến chính:

```yaml
es_cluster_name: prod-elasticsearch
es_version: 7.17.2

es_master_nodes:
  - es01
  - es02
  - es03

es_http_port: 9200
es_transport_port: 9300
es_heap_mb: 2048
```

Tên trong `es_master_nodes` phải trùng inventory host name.

### Dùng ổ data riêng

Ví dụ đã mount disk vào `/data`:

```yaml
es_data_path: /data/elasticsearch
es_require_data_mount: true
es_data_mountpoint: /data
```

Playbook sẽ dừng nếu `/data` chưa thực sự được mount, tránh ghi dữ liệu vào root disk.

### Chọn heap

`Xms` và `Xmx` được đặt bằng nhau. Tham khảo ban đầu:

| RAM/node | `es_heap_mb` tham khảo |
|---:|---:|
| 4 GB | 2048 |
| 8 GB | 4096 |
| 16 GB | 8192 |
| 32 GB | 16384 |
| 64 GB | 30720 |

Không dành hết RAM cho heap vì Lucene cần filesystem cache.

### Swap

Mặc định:

```yaml
es_disable_swap: true
```

Playbook chạy `swapoff -a` và comment các dòng swap đang hoạt động trong `/etc/fstab`. Chỉ giữ giá trị này trên node Elasticsearch chuyên dụng. Nếu server dùng chung và có chính sách swap riêng:

```yaml
es_disable_swap: false
```

## 5. Kiểm tra SSH và OS

```bash
ansible elasticsearch -m ping
ansible elasticsearch -m setup -a 'filter=ansible_distribution*'
```

Playbook chỉ tiếp tục khi target là Ubuntu `24.04`.

## 6. Cài cluster lần đầu

```bash
ansible-playbook site.yml
```

Luồng triển khai:

1. Kiểm tra Ubuntu 24.04, CPU, RAM, IP và topology.
2. Tải package `elasticsearch-7.17.2-<arch>.deb`.
3. Tải và xác minh checksum SHA-512 chính thức.
4. Cấu hình OS và systemd.
5. Ghi `cluster.initial_master_nodes` cho lần bootstrap đầu tiên.
6. Khởi động đồng thời các node.
7. Chờ đủ 3 node và health `yellow` hoặc `green`.
8. Tạo marker `/etc/elasticsearch/.ansible-cluster-bootstrapped`.
9. Xóa `cluster.initial_master_nodes` khỏi file mà không restart cluster.

Không xóa marker khi cluster còn dữ liệu.

## 7. Kiểm tra

```bash
ansible-playbook verify.yml
```

Hoặc:

```bash
curl -s http://10.10.10.11:9200/ | jq
curl -s http://10.10.10.11:9200/_cluster/health?pretty
curl -s 'http://10.10.10.11:9200/_cat/nodes?v&h=name,ip,node.role,master,version,heap.percent,ram.percent,cpu'
```

Kiểm tra port:

```bash
sudo ss -lntp | grep -E ':9200|:9300'
```

## 8. Firewall

Ví dụ subnet ứng dụng/quản trị là `10.10.20.0/24`, còn node Elasticsearch là `10.10.10.11-13`:

```bash
# Cho application/admin truy cập HTTP API.
sudo ufw allow from 10.10.20.0/24 to any port 9200 proto tcp

# Chỉ cho các node Elasticsearch giao tiếp transport.
sudo ufw allow from 10.10.10.11 to any port 9300 proto tcp
sudo ufw allow from 10.10.10.12 to any port 9300 proto tcp
sudo ufw allow from 10.10.10.13 to any port 9300 proto tcp
```

Nếu Ansible controller không nằm trong subnet trên, giữ rule SSH trước khi bật UFW.

## 9. Áp dụng thay đổi sau này

Dùng rolling update, mỗi lần một node:

```bash
ansible-playbook rolling-update.yml
```

Trước thay đổi production, cluster nên `green` và đã có snapshot kiểm thử khôi phục.

## 10. Cài offline

Đặt package trên Ansible controller và sửa:

```yaml
es_package_source: local
es_local_package_path: /opt/packages/elasticsearch-7.17.2-amd64.deb
es_local_package_sha512: "<SHA512_HEX>"
es_apt_update_cache: false
```

Các dependency Ubuntu vẫn phải có sẵn nếu node không truy cập Internet.

## 11. Xử lý lỗi

```bash
sudo systemctl status elasticsearch --no-pager -l
sudo journalctl -u elasticsearch -n 300 --no-pager
sudo tail -n 300 /var/log/elasticsearch/prod-elasticsearch.log
sudo sysctl vm.max_map_count
sudo -u elasticsearch /usr/share/elasticsearch/bin/elasticsearch --version
sudo /usr/share/elasticsearch/jdk/bin/java -version
```

Kiểm tra kết nối 9300 giữa các node:

```bash
nc -vz 10.10.10.11 9300
nc -vz 10.10.10.12 9300
nc -vz 10.10.10.13 9300
```

Nếu service không start sau khi đặt `network.host`, kiểm tra bootstrap checks trong log; Elasticsearch chuyển các cảnh báo cấu hình production thành lỗi dừng khởi động.

## 12. Nguyên tắc an toàn

- `cluster.initial_master_nodes` chỉ dùng để bootstrap cluster hoàn toàn mới.
- Không thêm lại thiết lập đó khi restart hoặc thêm node vào cluster hiện hữu.
- Không để nhiều node dùng chung `path.data`.
- Không đặt data trên NFS thông thường.
- Không đổi `cluster.name` trên cluster đã có dữ liệu nếu chưa có kế hoạch migration.
- Không xóa thư mục data để “sửa nhanh” khi chưa có snapshot và chưa xác định cluster UUID.
- Port `9300` chỉ dành cho transport giữa node, không dành cho ứng dụng HTTP.
