#!/usr/bin/env bash
set -euo pipefail

sudo apt-get update
sudo apt-get install -y python3 python3-venv openssh-client

python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/pip install 'ansible-core>=2.20,<2.22'

cat <<'MSG'
Ansible was installed in .venv.
Activate it with:
  source .venv/bin/activate
Then run:
  ansible-playbook --version
MSG
